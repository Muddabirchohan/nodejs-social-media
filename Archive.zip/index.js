const express = require("express");
const configureDbconn = require("./config/db.config");
const cookieParser = require("cookie-parser");
const userRoutes = require("./routes/user");
const app = express();
const port = process.env.PORT || 5000;
require('dotenv').config();

configureDbconn()

app.use(express.json());
app.use(cookieParser());

app.use("/user", userRoutes);

app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});

