const express = require('express')
const { adminAuth } = require('../auth/auth')
const { listAllUsers, createUser, findUserById, deleteUser, updateUser, login } = require('../controller/user.controller')
const router= express.Router()

router.post("/create", createUser)

router.post("/login",login)

router.get("/all", adminAuth, listAllUsers)

router.get("/findById/:userId", findUserById)

router.get("/deleteUser/:userId", deleteUser)

router.get("/updateUser/:userId", updateUser)

module.exports = router